#!/system/bin/sh
#
# Copyright (C) 2022 TheHitMan7

# Default GMS Process
GMS_PKG='com.google.android.gms'
GMS_PROC='com.google.android.gms.unstable'

# Magisk DB Settings
SELECT="SELECT value FROM settings WHERE key='zygisk'"

# Get Zygisk State from Magisk DB
ZYGISK=$(magisk --sqlite "$SELECT" | cut -d= -f2)

# Wait for post processes to finish
unset ZYGISK

# Reflect Zygisk State from Magisk DB
ZYGISK=$(magisk --sqlite "$SELECT" | cut -d= -f2)

# Check Zygisk State
if [ ! "$ZYGISK" ]; then
  return 1
elif [ "$ZYGISK" != "1" ]; then
  return 1
else
  sleep 0.5
fi

# Enable MagiskHide after Zygisk
magiskhide enable

# Handle GMS Process
if magiskhide status >/dev/null 2>&1; then
  magiskhide add $GMS_PKG $GMS_PKG
  magiskhide add $GMS_PKG $GMS_PROC
fi
